// Fill out your copyright notice in the Description page of Project Settings.


#include "SystemItems/SoarFantasyInterface.h"

// Add default functionality here for any ISoarFantasyInterface functions that are not pure virtual.

void ISoarFantasyInterface::AddCoinScore(int32 Score)
{

}

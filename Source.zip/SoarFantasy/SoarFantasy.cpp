// Copyright Epic Games, Inc. All Rights Reserved.

#include "SoarFantasy.h"
#include "Modules/ModuleManager.h"

IMPLEMENT_PRIMARY_GAME_MODULE( FDefaultGameModuleImpl, SoarFantasy, "SoarFantasy" );
